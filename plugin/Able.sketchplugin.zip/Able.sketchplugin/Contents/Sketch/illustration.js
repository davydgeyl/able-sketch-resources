@import 'annotation.js'

const colorSchemeBlueName = "Blue"
const colorSchemeGreenName = "Green"
const colorSchemeMagentaName = "Magenta"
const colorSchemeNeutralName = "Neutral."

function illustrationApplyBlue(context) {
	illustrationApplyColourScheme(context, colorSchemeBlueName)
}

function illustrationApplyGreen(context) {
	illustrationApplyColourScheme(context, colorSchemeGreenName)
}

function illustrationApplyMagenta(context) {
	illustrationApplyColourScheme(context, colorSchemeMagentaName)
}

function illustrationApplyNeutral(context) {
	illustrationApplyColourScheme(context, colorSchemeNeutralName)
}

function illustrationApplyColourScheme(context, colorSchemeName) {
	let sketch = require('sketch')
	let document = sketch.getSelectedDocument()
	let selection = document.selectedLayers.layers

	selection.forEach(layer => {
		applyColourSchemeToLayer(layer, document, colorSchemeName)
	})
}

function applyColourSchemeToLayer(layer, document, colorSchemeName) {
	switch (layer.type) {
	case "Artboard":
	case "Group":
		layer.layers.forEach(layer => {
			applyColourSchemeToLayer(layer, document, colorSchemeName)
		})
		break;
	case "SymbolInstance":
		var symbolName = "Unknown"
		var symbolMaster = document.getSymbolMasterWithID(layer.symbolId)
		if (symbolMaster) {
			symbolName = symbolMaster.name
		}
		
		var overrides = overridesOf(layer, document)
		var patternNameComponents = cleanedNameComponents(symbolName)
		
		var groupName = patternNameComponents[0].replace("🚧WIP", "")
		if (groupName == "picto") {			
			layer.overrides.forEach(override => {				
				let overrideName = override.affectedLayer.name.replace(/[^\x00-\x7F]/g, "").trim()
				
				if (overrideName == "Stroke" || overrideName == "Shade") {					
					var sharedStyle = document.getSharedLayerStyleWithID(override.value)
					if (sharedStyle) {
						let newStyle = styleFromStyleInColourScheme(sharedStyle, colorSchemeName, document)
						if (newStyle) {
							layer.setOverrideValue(override, newStyle.id)
						}
					}
				}
			})
		}
		break;
	default:
	}
}

function styleFromStyleInColourScheme(sharedStyle, colorSchemeName, document) {
	var sharedStyleName = sharedStyle.name
	var desiredStyleName = styleNameForScheme(sharedStyleName, colorSchemeName)
	desiredSharedStyle = document.sharedLayerStyles.find(sharedStyle => sharedStyle.name == desiredStyleName)
	
	if (desiredSharedStyle == null) {		
		var originalLibrary = sharedStyle.getLibrary()
		// Could not find the shared style in document. Try to import from the library
		var stylesReferences = originalLibrary.getImportableLayerStyleReferencesForDocument(document)
		let librarySharedStyle = stylesReferences.find(sharedStyle => sharedStyle.name == desiredStyleName)
		if (librarySharedStyle) {
			let style = librarySharedStyle.import()
			if (style) {
				desiredSharedStyle = style
			}
		}							
	}
	
	if (desiredSharedStyle == null) {
		log("ERROR: Could not find desiredSharedStyle: " + desiredStyleName)
		alertMissingStyle(desiredStyleName)
		return null
	} else {
		return desiredSharedStyle
	}
}

function styleNameForScheme(styleName, colorSchemeName) {
	// A bit blunt approach, but this replaces all possible occurances of color scheme name with the desired one
	return styleName.replace(colorSchemeBlueName, colorSchemeName).replace(colorSchemeGreenName, colorSchemeName).replace(colorSchemeMagentaName, colorSchemeName).replace(colorSchemeNeutralName, colorSchemeName)
}

function alertMissingStyle(styleName) {
	var dialog = NSAlert.alloc().init();
	dialog.addButtonWithTitle("OK");
	dialog.setMessageText('Failed to find the style:' + styleName)
	dialog.setInformativeText('Please contact the Able team regarding this message.')
	dialog.runModal();
}